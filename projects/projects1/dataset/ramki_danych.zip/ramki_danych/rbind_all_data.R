#Arkadiusz Kniaz 305713 
setwd("archive")
folders <- list.dirs(full.names = FALSE, recursive = FALSE)
all_data <- data.frame()
for (folder in folders) {
  setwd(paste0("archive/", folder))
  files <- list.files(pattern = "*.csv")
  for (file in files) {
    data <- read.csv(file)
    data$style <- folder
    all_data <- rbind(all_data, data)
  }
}
setwd("archive")
write.csv(all_data, "all_data.csv", row.names = FALSE)
