# Klasyfikacja
m <- 1500
# Niezr?wnowazone klasy
z <- sample(0:1,size=m, replace = TRUE,c(0.3,0.7))
z0 <- sum(z==0)
z1 <- sum(z==1)
# Klasa "1" rozdzielana przez klasę "0"
w1 <- numeric(m)
w1[z==0] <- rnorm(z0)
w1[z==1] <- sample(c(-1,1), z1, replace=TRUE)*rnorm(z1, 1.5, 1)
# Nieskorelowana zmienna
w2 <- rnorm(n,0,5) + rgamma(n,1,1)
# Nieznormalizowana + NULL
w3 <- numeric(m)
w3[z==0] <- rnorm(z0, 150, 20)
w3[z==1] <- rnorm(z1, 165, 15)
w3_NULL <- rbinom(m,1,prob=0.1)
w3[w3_NULL] <- NaN
# Duzo dyskretnych klas
classes <- 1:15
probs0 <- classes/sum(classes)
w4 <- numeric(m)
w4[z==0] <- sample(1:15, z0, replace=TRUE, prob = probs0)
probs1 <- 15:1/sum(15:1)
w4[z==1] <- sample(1:15, z1, replace=TRUE, prob = probs1)
# Duze odchylenie w jednej klasie
w5 <- numeric(m)
w5[z==0] <- rnorm(z0)
w5[z==1] <- rnorm(z1, 0.5, 5)
# NULL i dyskretna
w6 <- numeric(n)
prob0 <- c(0.35, 0.30, 0.20, 0.15)
prob1 <- c(0.20, 0.10, 0.40, 0.30)
w6[y==0] <- sample(1:4,y0, replace=TRUE, prob=prob0)
w6[y==1] <- sample(1:4,y1, replace=TRUE, prob=prob1)
w6_NULL <- rbinom(n,1,prob=0.05)
w6[x2_NULL==1] <- NaN
dataClassification <- data.frame(w1,w2,w3,w4,w5,w6,z)