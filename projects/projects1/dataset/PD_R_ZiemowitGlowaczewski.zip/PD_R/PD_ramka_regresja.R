
# Regresja
n <- 1000
# Do zależności kwadratowej 
# Nakładanie się modułów mimo dużej rozbieżności wartości
w1 <- rnorm(n,1,5)
# Zależne kolumny + czy to kategoryczna czy liczbowa (x3)
w2 <- runif(n,0,1)
w3 <- numeric(n)
for(i in 1:n) {
  w3[i] <- rbinom(1,5,w2[i])
}
# NULL
w4 <- rbeta(n,1,2)
w4_NULL <- rbinom(n,1,prob=0.1)
w4[w4_NULL] <- NaN
# Skupienia daleko od siebie
w5_pom <- rbinom(n,2,prob=0.1)
w5 <- numeric(n)
w5[w5_pom==0] <- rnorm( length(sum(w5_pom[w5_pom==0])), 0, 2 )
w5[w5_pom==1] <- rnorm( length(sum(w5_pom[w5_pom==1])), 3, 2 )
w5[w5_pom==2] <- rnorm( length(sum(w5_pom[w5_pom==1])), 5, 2 )
# Kategoryczna
w6 <- numeric(n)
w6_pom <- rbinom(n,3,prob=0.6)
for (i in 1:n){
  w6[i] = w6_pom[i] 
}
# Nieskorelowana duże wartości
w7 <- 10*rnorm(n, 5, 5)
# Y
beta <- c(0.7,0.5,0.22,0.14,-1.2,0.9,0)
df <- as.matrix(w1,w2,w3,w4,w5,w6,w7)
y <- df%*%beta + rnorm(n,0,1.111)
